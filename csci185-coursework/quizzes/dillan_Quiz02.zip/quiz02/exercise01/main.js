function showFox() {
    // your code here...
    document.querySelector(".card").innerHTML = `          
    <img src="images/fox.jpg" />
    <p>Fox</p>`
    console.log('Change image and paragraph to fox...');
}

function showLion() {
    // your code here...
    document.querySelector(".card").innerHTML = `          
    <img src="images/lion.jpg" />
    <p>Lion</p>`
    console.log('Change image and paragraph to lion...');
}

function showTiger() {
    document.querySelector(".card").innerHTML = `          
    <img src="images/tiger.png" />
    <p>Tiger</p>`
    // your code here...
    console.log('Change image and paragraph to tiger...');
}

function showZebra() {
    // your code here...
    document.querySelector(".card").innerHTML = `          
    <img src="images/zebra.jpg" />
    <p>Zebra</p>`
    console.log('Change image and paragraph to zebra...');
}

